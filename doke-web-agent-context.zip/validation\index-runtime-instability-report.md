# Index Runtime Instability Report

**Escopo:** `index.html`, seção `Destaques para você`, diferença entre loading/primeiro paint e estado carregado.

## Achado principal
O `index.html` carrega poucos CSS diretamente, mas carrega muitos scripts de runtime/data/controller. Isso muda a natureza do problema: a divergência provavelmente não está só na ordem de CSS estático; ela também envolve **estado de lista**, **classes/datasets adicionados no runtime** e possível diferença entre **markup estático `.doke-ad-card`** e **renderização dinâmica `.service-card`/renderers**.

## CSS direto do index
| Ordem | CSS | !important | Risco |
|---:|---|---:|---:|
| 1 | `assets/css/core/index.css` | 0 | 0 |
| 2 | `assets/css/pages/app-shell.css` | 0 | 0 |
| 3 | `assets/css/pages/home.css` | 131 | 17 |

## Scripts do index com sinais de mutação
| Script | Stylesheet dinâmico | Mutação de classe/data | Troca DOM/lista |
|---|---:|---:|---:|
| `assets/js/components/ad-card-interactions.js` | 0 | 14 | 0 |
| `assets/js/components/mobile-app-shell.js` | 0 | 25 | 0 |
| `assets/js/controllers/controller-bootstrap.js` | 0 | 2 | 0 |
| `assets/js/core/app.js` | 8 | 43 | 1 |
| `assets/js/core/dom.js` | 0 | 0 | 1 |
| `assets/js/core/feature-flags.js` | 0 | 3 | 0 |
| `assets/js/core/ipad-safari-early-guard.js` | 0 | 1 | 0 |
| `assets/js/core/ipad-safari-scroll-guard.js` | 0 | 4 | 0 |
| `assets/js/core/list-state.js` | 0 | 1 | 3 |
| `assets/js/core/page-bootstrap.js` | 0 | 2 | 0 |
| `assets/js/core/shell-state-early.js` | 0 | 1 | 0 |
| `assets/js/core/stable-shell-router.js` | 9 | 18 | 0 |
| `assets/js/core/view-state.js` | 0 | 1 | 0 |
| `assets/js/pages/home/before-after.js` | 3 | 22 | 0 |
| `assets/js/pages/home/filter-route.js` | 0 | 1 | 0 |
| `assets/js/pages/home/filters.js` | 0 | 15 | 0 |
| `assets/js/pages/home/mobile-interaction-contract.js` | 0 | 26 | 0 |
| `assets/js/pages/home/search.js` | 0 | 13 | 3 |
| `assets/js/pages/home/workers.js` | 0 | 24 | 0 |
| `assets/js/pages/home.js` | 0 | 27 | 2 |
| `assets/js/pages/index-data-controller.js` | 0 | 8 | 0 |
| `assets/js/pages/search-results.js` | 0 | 19 | 8 |
| `assets/js/services/auth-service.js` | 0 | 1 | 0 |
| `assets/js/state/state-contracts.js` | 0 | 3 | 0 |
| `assets/js/ui/mobile-drawer-standard.js` | 0 | 1 | 0 |
| `assets/js/ui/mobile-drawer.js` | 0 | 9 | 0 |
| `assets/js/ui/mobile-interaction-standard.js` | 0 | 1 | 0 |
| `assets/js/ui/mobile-overlay-system.js` | 0 | 1 | 0 |

## Ponto crítico encontrado
A seção `featured-services` no HTML usa cards estáticos com classe `.doke-ad-card`. O pipeline de dados da home (`index-data-controller.js`) registra a região `featured-services` e muda `data-state` para `loading`/`ready`. O projeto também possui renderers de serviço que produzem `.service-card service-card--result doke-card doke-service-card`. Se qualquer camada posterior renderizar ou alternar estado com CSS diferente para `.service-card` versus `.doke-ad-card`, o usuário verá exatamente o efeito relatado: card em um formato durante loading e outro após carregamento.

## Correção correta, sem remendo
1. Definir se `featured-services` deve usar `.doke-ad-card` ou `.service-card` como contrato final. Não pode depender de um no HTML estático e outro no renderer.
2. Se a home futura será data-ready, o renderer deve emitir a mesma anatomia visual do index ou o index deve adotar o componente canônico renderizado desde o HTML inicial.
3. CSS de `featured-services` deve cuidar só do rail/contexto da seção. Anatomia do card deve ficar no componente canônico.
4. `data-state="loading"/"ready"` não deve alterar largura/altura/anatomia de card; só visibilidade/estado sem layout shift.
5. Validar antes/depois do `DOMContentLoaded` e após `doke:index-data-ready`.

## Não fazer
- Não criar `index-fix.css`, `home-final.css` ou novo override tardio.
- Não aplicar `!important` para congelar dimensões.
- Não corrigir `.doke-ad-card` se o DOM carregado final estiver virando `.service-card`.

/* Doke shell state early bootstrap.
   Runs in <head> before CSS so sidebar/workspace geometry starts in the
   same state used after app.js hydrates the shell. */
(function () {
  var root = document.documentElement;
  var storageKey = "doke.sidebar.collapsed";
  var READY = "doke-shell-state-ready";
  var COLLAPSED = "doke-sidebar-collapsed";
  var EXPANDED = "doke-sidebar-expanded";
  var LEGACY_WIDTH_VARS = [
    "--doke-home-desktop-gutter",
    "--doke-home-desktop-workspace",
    "--home-desktop-content-width"
  ];

  function isDesktopShell() {
    try {
      return window.matchMedia("(min-width: 1200px)").matches;
    } catch (error) {
      var width = window.innerWidth || root.clientWidth || 0;
      return width >= 1200;
    }
  }

  function isTabletShell() {
    return false;
  }

  function isMobileRuntime() {
    try {
      return window.matchMedia("(max-width: 560px), ((hover: none) and (pointer: coarse) and (max-device-width: 560px))").matches;
    } catch (error) {
      var width = window.innerWidth || root.clientWidth || 0;
      var touchPhone = false;
      try {
        touchPhone = navigator.maxTouchPoints > 0 && window.screen && Math.min(window.screen.width || 0, window.screen.height || 0) <= 560;
      } catch (innerError) {}
      return width <= 560 || touchPhone;
    }
  }

  function syncViewportContract() {
    var viewportHeight = window.innerHeight || root.clientHeight || 0;
    var viewportWidth = window.innerWidth || root.clientWidth || 0;
    var scrollbarWidth = Math.max(0, viewportWidth - root.clientWidth);
    var mobile = isMobileRuntime();

    root.classList.toggle("doke-js-mobile", mobile);
    root.classList.toggle("doke-js-desktop", !mobile);
    root.style.setProperty("--doke-js-vh", ((viewportHeight || 0) * 0.01).toFixed(2) + "px");
    root.style.setProperty("--doke-window-width", viewportWidth + "px");
    root.style.setProperty("--doke-layout-width", Math.max(0, viewportWidth - scrollbarWidth) + "px");
    root.style.setProperty("--doke-scrollbar-width", scrollbarWidth + "px");
  }

  function readCollapsed() {
    try {
      return window.localStorage.getItem(storageKey) === "true";
    } catch (error) {
      return false;
    }
  }

  function applyShellState() {
    var desktopShell = isDesktopShell();
    var mobileShell = isMobileRuntime();
    var tabletShell = isTabletShell();
    var shouldCollapse = desktopShell && readCollapsed();
    var sidebarWidth = desktopShell ? (shouldCollapse ? "92px" : "240px") : "0px";

    syncViewportContract();
    root.classList.toggle(COLLAPSED, shouldCollapse);
    root.classList.toggle(EXPANDED, !shouldCollapse);
    root.classList.toggle("doke-mobile-shell-pending", mobileShell && !root.classList.contains("doke-mobile-shell-ready"));
    root.classList.add(READY);

    root.style.setProperty("--doke-current-sidebar-width", sidebarWidth);
    root.style.setProperty("--sidebar-width", sidebarWidth);
    root.style.setProperty("--doke-desktop-sidebar-width", sidebarWidth);
    root.style.setProperty("--doke-app-sidebar-width", sidebarWidth);
    root.style.setProperty("--doke-app-shell-sidebar-width", sidebarWidth);
    root.style.setProperty("--doke-home-sidebar-width", sidebarWidth);
    LEGACY_WIDTH_VARS.forEach(function (name) {
      root.style.removeProperty(name);
    });
  }

  applyShellState();
  window.addEventListener("pageshow", applyShellState, { passive: true });
  window.addEventListener("resize", applyShellState, { passive: true });
  window.addEventListener("orientationchange", applyShellState, { passive: true });
})();

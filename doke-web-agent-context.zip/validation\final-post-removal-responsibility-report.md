# Stage 65 — Final Post-Removal Audit / Responsibility Report

Generated at: `2026-06-11T01:52:44Z`

## Purpose

This stage closes the post-removal audit after the second controlled dormant CSS removal. It does not change production HTML/CSS/JS. Its job is to document the current structural baseline, ownership boundaries, remaining risk, and the entry criteria for the final structural gate before Visual Recovery.

## Production changes

- Production HTML changed: **no**
- Production CSS changed: **no**
- Production JS changed: **no**
- Physical deletion performed: **no**

## Structural metrics

- `active_html_files`: **21**
- `physical_css_files`: **390**
- `direct_css_entrypoints_unique`: **22**
- `reachable_css_files`: **277**
- `not_reachable_css_files`: **113**
- `html_css_link_errors`: **0**
- `css_import_errors`: **0**
- `css_brace_errors`: **0**
- `important_total_files_assets_css`: **30**
- `important_total_occurrences_assets_css`: **12325**
- `important_reachable_files`: **0**
- `important_reachable_occurrences`: **0**
- `important_dormant_files`: **30**
- `important_dormant_occurrences`: **12325**
- `pages_with_more_than_one_local_css`: **2**
- `foundation_manifests`: **24**
- `forbidden_name_css_remaining`: **2**
- `legacy_authority_files_remaining_by_basename`: **15**
- `legacy_authority_files_active_by_basename`: **3**
- `legacy_authority_files_dormant_by_basename`: **12**

## CSS direct-load state by active page

- `ajuda.html`: **1** local CSS link(s)
- `anunciar-servico.html`: **1** local CSS link(s)
- `auth/cadastro.html`: **1** local CSS link(s)
- `auth/esqueci-senha.html`: **1** local CSS link(s)
- `auth/login.html`: **1** local CSS link(s)
- `avaliacao-profissional.html`: **1** local CSS link(s)
- `avaliacao.html`: **1** local CSS link(s)
- `carteira.html`: **1** local CSS link(s)
- `comunidade-interna.html`: **1** local CSS link(s)
- `comunidade.html`: **3** local CSS link(s) — outlier kept intentionally
- `configuracoes.html`: **1** local CSS link(s)
- `detalhe-anuncio.html`: **1** local CSS link(s)
- `index.html`: **1** local CSS link(s)
- `mensagens.html`: **1** local CSS link(s)
- `notificacoes.html`: **1** local CSS link(s)
- `novidades.html`: **1** local CSS link(s)
- `pagamento-profissional.html`: **1** local CSS link(s)
- `pedidos.html`: **1** local CSS link(s)
- `perfil.html`: **1** local CSS link(s)
- `resultados.html`: **2** local CSS link(s) — outlier kept intentionally
- `tornar-profissional.html`: **1** local CSS link(s)

## Direct CSS entrypoints

- `assets/css/pages/ajuda-foundation.css`
- `assets/css/pages/anunciar-servico-foundation.css`
- `assets/css/pages/auth-foundation.css`
- `assets/css/pages/avaliacao-foundation.css`
- `assets/css/pages/avaliacao-profissional-foundation.css`
- `assets/css/pages/carteira-foundation.css`
- `assets/css/pages/comunidade-foundation.css`
- `assets/css/pages/comunidade-interna-foundation.css`
- `assets/css/pages/comunidade-post-shell-foundation.css`
- `assets/css/pages/comunidade-ui-foundation.css`
- `assets/css/pages/configuracoes-foundation.css`
- `assets/css/pages/home-foundation.css`
- `assets/css/pages/marketplace-detail-foundation.css`
- `assets/css/pages/marketplace-foundation.css`
- `assets/css/pages/messaging-foundation.css`
- `assets/css/pages/notificacoes-foundation.css`
- `assets/css/pages/novidades-foundation.css`
- `assets/css/pages/pagamento-profissional-foundation.css`
- `assets/css/pages/pedidos-foundation.css`
- `assets/css/pages/profile-foundation.css`
- `assets/css/pages/search-results.css`
- `assets/css/pages/tornar-profissional-foundation.css`

## Responsibility layer count — reachable CSS only

- `core`: **16** file(s)
- `layout`: **3** file(s)
- `components`: **96** file(s)
- `patterns`: **10** file(s)
- `pages`: **152** file(s)
- `utilities`: **0** file(s)
- `other`: **0** file(s)

## Responsibility rules confirmed

- `core`: foundation only — tokens, reset, base typography, variables. No page-specific authority should be added here.
- `layout`: shell/header/rail/sidebar/global responsive contracts. Do not use it to fix local component anatomy.
- `components`: reusable pieces such as cards, buttons, inputs, avatars, badges, tabs, modals, bottom navigation and search pieces.
- `patterns`: reusable composition such as rails, carousels, grids, lists, feeds, section headers and marketplace composition.
- `pages`: page composition, section order, page-specific spacing and small documented exceptions. It must not redefine shared card anatomy.
- `utilities`: small helpers for visibility, accessibility, scroll and minimal spacing.
- `JS`: controllers/renderers. JS must not mutate visual anatomy after loading to compensate for CSS conflicts.

## Remaining structural risk

- Dormant/non-reachable CSS remains: **113** file(s).
- Dormant files containing `!important`: **30** file(s), **12325** occurrence(s).
- Reachable/active `!important`: **0** occurrence(s).
- Pages still loading more than one local CSS file: **2** (`comunidade.html, resultados.html`).

## Dormant CSS classification

- `docs_or_reports_only`: **69**
- `blocked_runtime`: **0**
- `blocked_config`: **5**
- `blocked_scripts`: **29**
- `blocked_css_text`: **10**

## Gate results

- Broken CSS links in active HTML: **0**
- Broken CSS imports: **0**
- CSS files with unbalanced braces: **0**
- Reachable CSS with `!important`: **0**

## Legacy authority file status

Some legacy authority basenames still exist after the dormant removals. This does **not** mean they were reactivated in this stage; it means the current active graph still needs a final containment pass before Visual Recovery.

### Still reachable / active
- `assets/css/components/cards/mobile-card-distribution-contract.css`
- `assets/css/components/shell/desktop-page-rail-authority.css`
- `assets/css/components/shell/shared-page-width-contract.css`

### Dormant / not reachable
- `assets/css/components/layout/responsive-page-contract.css`
- `assets/css/components/layout/responsive-priority-cards.css`
- `assets/css/components/layout/responsive-priority-contract.css`
- `assets/css/components/navigation/app-header.css`
- `assets/css/components/shell/app-header-canonical-contract.css`
- `assets/css/components/shell/app-header.css`
- `assets/css/components/shell/doke-shell-contract.css`
- `assets/css/components/shell/ipad-safari-scroll.css`
- `assets/css/components/shell/mobile-app-shell.css`
- `assets/css/components/shell/tablet-internal-rail-contract.css`
- `assets/css/patterns/marketplace-responsive-stack.css`
- `assets/css/patterns/mobile-app-shell.css`

### Decision

The final structural gate should not be claimed as fully passed until the active legacy authority files are either migrated into the correct `layout/components/patterns` ownership or explicitly documented as temporary compatibility shims with a removal plan.

## Visual Recovery note

The visual state may be degraded because this phase intentionally prioritized structural predictability over polish. Do not start patching visuals from screenshots yet. First run the final structural gate, then start Visual Recovery with explicit page/component ownership and `index.html` as the visual canonical reference for cards, rails, carousels, density, workers and publications.

## Recommended next stage

**Stage 66 — Legacy Authority Containment / Final Gate Preparation**

Recommended scope: reconcile the active legacy authority imports, decide whether they become temporary shims or are migrated into correct ownership, then run the final structural gate and prepare the Visual Recovery handoff.

